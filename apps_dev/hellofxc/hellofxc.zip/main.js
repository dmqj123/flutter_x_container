function main(){
    window.flutter_inappwebview.callHandler('fxc_api_call',['test','Hello World!']);
}