import 'package:flutter/material.dart';

Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text("FlutterX Container"),
          ],
        ),
      ),
    );
  }